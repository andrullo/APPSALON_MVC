<h1 class="nombre-pagina">Confirma tu cuenta</h1>
<p class="descripcion-pagina">Hemos enviado las instrucciones para confirmar la cuenta a su e-mail</p>